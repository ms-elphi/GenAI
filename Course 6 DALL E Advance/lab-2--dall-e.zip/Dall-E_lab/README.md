# Dall-E_lab


This is the starting point for the Dall-E and PIL lab. 
