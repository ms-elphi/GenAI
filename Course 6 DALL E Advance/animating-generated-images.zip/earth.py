import main
from PIL import Image
'''
def generate_earth_image(angle):
    prompt = f"Realistic Earth from space at {angle} degrees angle"
    image_url = main.generate_base_image(prompt)
    image_filename = f"earth_{angle}_degrees"
    image = main.download_image(image_url, image_filename)
    return image


angles = range(0, 360, 10)
earth_images = [generate_earth_image(angle) for angle in angles]

'''
