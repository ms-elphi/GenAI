import os

# Set environment variables
keys = os.getenv('OPENAI_KEY')

api_key= keys


