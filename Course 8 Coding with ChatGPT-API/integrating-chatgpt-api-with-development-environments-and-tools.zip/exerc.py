import os
import openai
import secret
# WRITE YOUR CODE HERE

