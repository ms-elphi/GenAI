This is the starting point for Lab 1: The Simple Bot in the Select Topics, NLP course.
