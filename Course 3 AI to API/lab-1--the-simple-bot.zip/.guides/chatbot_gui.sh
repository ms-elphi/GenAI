#!/bin/bash
 
nohup python3.9 nlp-apibot/chatbot_gui.py > /dev/null 2>&1&