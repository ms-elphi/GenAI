#!/bin/bash
 
nohup python3.9 nlp-simplebot/simplebot_nltk.py > /dev/null 2>&1&