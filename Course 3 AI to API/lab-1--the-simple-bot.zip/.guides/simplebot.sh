#!/bin/bash
 
nohup python3.9 nlp-simplebot/simplebot.py > /dev/null 2>&1&